/**
 * Created by djdapz on 3/31/16.
 */
(function(angular) {
    angular.module("app", []);

}(angular));